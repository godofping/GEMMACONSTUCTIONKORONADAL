<!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Menu</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="admin-home.php">Dashboard</a></li>
                      <li><a href="profile.php">Profile</a></li>
                      
                    </ul>
                  </li>

                   <li><a><i class="fa fa-bus"></i>Products <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <li><a href="products.php">Add | Edit | Delete Products</a></li>
                   
                      
                      
                    </ul>
                  </li>
                  
                  <li><a><i class="fa fa-user"></i>Engineers <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <li><a href="engineers.php">Add | Edit | Delete Engineers</a></li>
                   
                      
                      
                    </ul>
                  </li>
                  
                  <li><a><i class="fa fa-product-hunt"></i>Projects <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <li><a href="projects.php">Add | Edit | Delete Projects</a></li>
                   
                      
                      
                    </ul>
                  </li>

                  <li><a><i class="fa fa-list-ul"></i>Inventory <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <li><a href="inventory.php">Manage Inventory</a></li>
                   
                      
                      
                    </ul>
                  </li>


                 
                </ul>
              </div>
             

            </div>
            <!-- /sidebar menu -->